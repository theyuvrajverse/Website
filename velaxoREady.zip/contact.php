<?php
/**
 * VELAXON — Contact Form Handler (contact.php)
 * ============================================================
 * WHAT THIS FILE DOES:
 * Receives the form POST from contact.html, validates and
 * sanitises every field, checks for bot spam (honeypot),
 * sends you an email notification, sends the enquirer an
 * auto-reply, logs the enquiry to a backup file, and returns
 * a JSON response that main.js uses to redirect the user.
 *
 * HOW TO DEPLOY:
 * 1. Upload this file to the ROOT of your website (same folder
 *    as index.html, about.html etc.) — NOT inside /php/
 *    (or update the fetch URL in main.js to match its location)
 * 2. Replace YOUR_EMAIL below with your real email
 * 3. Replace your phone number in the auto-reply section
 * 4. Create a /logs/ folder on the server (chmod 750)
 *
 * HOSTING NOTE:
 * On many Indian shared hosting plans (Hostinger, GoDaddy etc.),
 * PHP mail() is disabled. If you're not receiving emails, use
 * PHPMailer with SMTP instead (instructions in comments below).
 * ============================================================
 */

/* ── YOUR CONFIGURATION ──────────────────────────────────── */
define('YOUR_EMAIL', 'support@velaxon.in');   // ← CHANGE THIS
define('SITE_NAME',  'Velaxon');
define('SITE_URL',   'https://velaxon.in');

/* ── RESPONSE HEADERS ────────────────────────────────────── */
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

// Only process POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

/* ── HONEYPOT SPAM TRAP ──────────────────────────────────── */
// The form has a hidden field "website_url" that is invisible
// to humans (display:none in HTML). Real users never fill it.
// Bots always fill every field, so if this field has a value,
// we know it's a bot. We silently return success (don't tell
// the bot it failed) and exit without sending any email.
if (!empty($_POST['website_url'])) {
    echo json_encode(['success' => true]);
    exit;
}

/* ── HELPER: SANITISE INPUT ──────────────────────────────── */
// Always sanitise user input before using it anywhere.
// This prevents XSS (Cross-Site Scripting) attacks.
function sanitise(string $value): string {
    return htmlspecialchars(strip_tags(trim($value)), ENT_QUOTES, 'UTF-8');
}

/* ── READ AND SANITISE ALL FORM FIELDS ───────────────────── */
$name     = sanitise($_POST['name']     ?? '');
$business = sanitise($_POST['business'] ?? '');
$phone    = sanitise($_POST['phone']    ?? '');
$city     = sanitise($_POST['city']     ?? '');
$email    = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
$service  = sanitise($_POST['service']  ?? '');
$message  = sanitise($_POST['message']  ?? '');
$source   = sanitise($_POST['source']   ?? '');

/* ── SERVER-SIDE VALIDATION ──────────────────────────────── */
// Always validate on the server even though HTML5 validates on
// the client. Client-side validation can be bypassed by anyone.
$errors = [];

if (empty($name))     $errors[] = 'Name is required';
if (empty($business)) $errors[] = 'Business name is required';
if (empty($phone))    $errors[] = 'Phone number is required';
if (empty($city))     $errors[] = 'City is required';
if (empty($service))  $errors[] = 'Please select a service';

// Extract only digits from phone number for validation
// This handles formats like +91 98765 43210, 9876543210, etc.
$phoneDigits = preg_replace('/[^0-9]/', '', $phone);
if (strlen($phoneDigits) < 10) {
    $errors[] = 'Phone number must have at least 10 digits';
}

// Validate email only if provided (it's optional in our form)
if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Please enter a valid email address';
}

// If there are validation errors, return them to the browser
if (!empty($errors)) {
    http_response_code(422); // 422 = Unprocessable Entity
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

/* ── MAP FORM VALUES TO READABLE LABELS ──────────────────── */
// The form uses short codes for option values (e.g. 'gbp-setup').
// We map them to full readable labels for the email notification.

$serviceLabels = [
    'gbp-setup'   => 'Google Business Profile Setup',
    'website'     => 'Website Development',
    'vela-local'  => 'Vela Local Package (Website + GBP)',
    'maintenance' => 'Website Maintenance',
    'power-bi'    => 'Power BI / Business Intelligence',
    'not-sure'    => 'Not Sure — Needs Advice',
];
$serviceLabel = $serviceLabels[$service] ?? $service;

$sourceLabels = [
    'google'    => 'Google Search',
    'whatsapp'  => 'WhatsApp',
    'referral'  => 'Referral / Word of Mouth',
    'linkedin'  => 'LinkedIn',
    'instagram' => 'Instagram',
    'other'     => 'Other',
];
$sourceLabel = $sourceLabels[$source] ?? ($source ?: 'Not specified');

/* ── BUILD NOTIFICATION EMAIL TO YOU ────────────────────── */
$timestamp = date('d M Y, h:i A');

$subject = "New Velaxon Enquiry: {$name} — {$serviceLabel} [{$city}]";

$emailBody = "
============================================================
  NEW ENQUIRY — VELAXON
  {$timestamp}
============================================================

CONTACT DETAILS
  Name         : {$name}
  Business     : {$business}
  Phone/WA     : {$phone}
  City         : {$city}
  Email        : " . ($email ?: 'Not provided') . "

ENQUIRY
  Service      : {$serviceLabel}
  Heard From   : {$sourceLabel}

MESSAGE:
  {$message}

============================================================
QUICK ACTIONS (click to open)
  WhatsApp  : https://wa.me/{$phoneDigits}
  Email     : mailto:{$email}
============================================================
Source: " . SITE_URL . "/contact.html
============================================================
";

/* ── EMAIL HEADERS ───────────────────────────────────────── */
$mailHeaders  = "From: Velaxon Website <noreply@velaxon.in>\r\n";
$mailHeaders .= "Reply-To: {$name} <{$email}>\r\n";
$mailHeaders .= "MIME-Version: 1.0\r\n";
$mailHeaders .= "Content-Type: text/plain; charset=UTF-8\r\n";
$mailHeaders .= "X-Mailer: PHP/" . phpversion() . "\r\n";

/* ── SEND THE EMAIL ──────────────────────────────────────── */
// mail() is the built-in PHP email function.
// It returns true if the message was accepted for delivery.
// NOTE: acceptance does NOT guarantee delivery.
// If emails go to spam, switch to SMTP (see instructions below).
$emailSent = mail(YOUR_EMAIL, $subject, $emailBody, $mailHeaders);

/* ── AUTO-REPLY TO THE ENQUIRER ──────────────────────────── */
// Send a confirmation email to the person who filled the form.
// This is professional and reassures them their message arrived.
// Only send if they provided an email address.
if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {

    $replySubject = "We've received your enquiry — Velaxon";
    $replyBody    = "
Namaste {$name} ji,

Thank you for contacting Velaxon.

Your enquiry about '{$serviceLabel}' has been received.

We will review your current online presence and respond within
24 hours — usually within 4 hours on WhatsApp during business hours.

NEED TO REACH US URGENTLY?
  WhatsApp : https://wa.me/919608007474
  Email    : " . YOUR_EMAIL . "

Business Hours: Monday – Saturday, 10:00 AM – 7:00 PM

—
Yuvraj Sharma
Founder, Velaxon
Velocity Meets Intelligence
" . SITE_URL . "

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
This is an automated confirmation.
For replies, please use WhatsApp or email us directly.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    ";

    $replyHeaders  = "From: Velaxon <" . YOUR_EMAIL . ">\r\n";
    $replyHeaders .= "Reply-To: " . YOUR_EMAIL . "\r\n";
    $replyHeaders .= "MIME-Version: 1.0\r\n";
    $replyHeaders .= "Content-Type: text/plain; charset=UTF-8\r\n";

    // Use @ to suppress errors — auto-reply failure is not critical
    @mail($email, $replySubject, $replyBody, $replyHeaders);
}

/* ── LOG ENQUIRY TO BACKUP FILE ──────────────────────────── */
// Even if email fails, this log preserves every enquiry.
// IMPORTANT: Store the log file outside the publicly accessible
// web root for security. If your site root is /public_html/,
// create /logs/ at the same level as /public_html/, not inside it.
//
// Example server path:
//   Good: /home/youraccount/logs/enquiries.log
//   Bad:  /home/youraccount/public_html/logs/enquiries.log (accessible via browser)
//
// For now, this stores it in a /logs/ subfolder and we protect
// it with .htaccess (see the .htaccess file we create below).

$logDir  = __DIR__ . '/logs/';
$logFile = $logDir . 'enquiries.log';

if (!is_dir($logDir)) {
    @mkdir($logDir, 0750, true);
}

$logEntry = date('Y-m-d H:i:s') . ' | '
    . json_encode([
        'name'     => $name,
        'business' => $business,
        'phone'    => $phone,
        'city'     => $city,
        'email'    => $email,
        'service'  => $serviceLabel,
        'message'  => $message,
        'source'   => $sourceLabel,
        'sent'     => $emailSent,
        'ip'       => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    ]) . "\n";

@file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);

/* ── SEND FINAL RESPONSE TO JAVASCRIPT ───────────────────── */
// main.js is waiting for this response.
// { success: true }  → JS redirects to thankyou.html
// { success: false } → JS shows error alert with WhatsApp fallback
//
// We return success:true even if mail() failed because the log
// file captured the enquiry. The user should not see an error
// for something that is a server-side configuration issue.

echo json_encode([
    'success' => true,
    'sent'    => $emailSent,
]);
exit;

/*
============================================================
  UPGRADE: PHPMAILER WITH SMTP (Recommended for production)
============================================================
If mail() is not working on your hosting (very common on
Indian shared hosting), use PHPMailer with Gmail SMTP.

STEP 1: Install PHPMailer via Composer
  composer require phpmailer/phpmailer

STEP 2: Replace the mail() section above with this:

  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\Exception;

  require 'vendor/autoload.php';

  $mail = new PHPMailer(true);
  try {
      $mail->isSMTP();
      $mail->Host       = 'smtp.gmail.com';
      $mail->SMTPAuth   = true;
      $mail->Username   = 'yourgmail@gmail.com';     // Your Gmail
      $mail->Password   = 'your-app-password';        // Gmail App Password
      $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
      $mail->Port       = 587;

      $mail->setFrom('noreply@velaxon.in', 'Velaxon Website');
      $mail->addAddress(YOUR_EMAIL, 'Velaxon');
      $mail->addReplyTo($email, $name);

      $mail->Subject = $subject;
      $mail->Body    = $emailBody;

      $emailSent = $mail->send();
  } catch (Exception $e) {
      $emailSent = false;
      // Log the error: $mail->ErrorInfo
  }

GMAIL APP PASSWORD:
  Go to Google Account → Security → 2-Step Verification → App Passwords
  Create one for "Mail" and use it as the Password above.
  Never use your actual Gmail password.

ZOHO MAIL (Professional — has free plan):
  Host: smtp.zoho.in
  Port: 587
  Use your Zoho email and password.
  This gives you a professional @velaxon.in address.
============================================================
*/
