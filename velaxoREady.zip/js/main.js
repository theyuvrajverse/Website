document.addEventListener('DOMContentLoaded', function () {

  /* NAV */
  const nav       = document.querySelector('.nav');
  const hamburger = document.querySelector('.nav__hamburger');
  const mobileNav = document.querySelector('.nav__mobile');

  function handleNavScroll() {
    if (nav) nav.classList.toggle('scrolled', window.scrollY > 40);
  }
  window.addEventListener('scroll', handleNavScroll, { passive: true });
  handleNavScroll();

  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', function() {
      mobileNav.classList.toggle('open');
      document.body.style.overflow = mobileNav.classList.contains('open') ? 'hidden' : '';
    });
  }

  document.querySelectorAll('.nav__mobile-link, .nav__mobile-close').forEach(function(el) {
    el.addEventListener('click', function() {
      if (mobileNav) mobileNav.classList.remove('open');
      document.body.style.overflow = '';
    });
  });

  // Active link highlight
  var current = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav__link').forEach(function(link) {
    if (link.getAttribute('href') === current) link.classList.add('active');
  });

  /* SCROLL ANIMATIONS */
  var animated = document.querySelectorAll('[data-animate]');
  if (animated.length && window.IntersectionObserver) {
    var observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    animated.forEach(function(el) { observer.observe(el); });
  } else {
    animated.forEach(function(el) { el.classList.add('in-view'); });
  }

  /* CONTACT FORM */
  var form = document.getElementById('contactForm');
  if (form) {
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      var btn = form.querySelector('.form__submit');
      var orig = btn.textContent;
      btn.textContent = 'Sending…';
      btn.disabled = true;

      fetch('contact.php', {
        method: 'POST',
        body: new FormData(form),
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      })
      .then(function(r) { return r.json(); })
      .then(function(d) {
        if (d.success) {
          window.location.href = 'thankyou.html';
        } else {
          btn.textContent = orig;
          btn.disabled = false;
          alert('Something went wrong. Please WhatsApp us directly.');
        }
      })
      .catch(function() {
        window.location.href = 'thankyou.html';
      });
    });
  }

  /* SMOOTH ANCHORS */
  document.querySelectorAll('a[href^="#"]').forEach(function(a) {
    a.addEventListener('click', function(e) {
      var target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        window.scrollTo({ top: target.getBoundingClientRect().top + window.scrollY - 80, behavior: 'smooth' });
      }
    });
  });

});
const progressBar=document.querySelector('.reading-progress');

if(progressBar){

window.addEventListener('scroll',()=>{

const height=
document.documentElement.scrollHeight-
window.innerHeight;

const progress=
(window.scrollY/height)*100;

progressBar.style.width=progress+'%';

});

}

const contactForm =
document.getElementById('contactForm');

if(contactForm){

contactForm.addEventListener(
'submit',
function(e){

let valid = true;

const errors =
document.querySelectorAll('.form-error');

errors.forEach(error=>{
error.textContent='';
});

const name =
document.getElementById('name');

const business =
document.getElementById('business');

const phone =
document.getElementById('phone');

const city =
document.getElementById('city');

const service =
document.getElementById('service');

const email =
document.getElementById('email');


// Name

if(name.value.trim().length < 2){

name.parentElement
.querySelector('.form-error')
.textContent =
'Please enter your name';

valid = false;

}


// Business

if(business.value.trim().length < 2){

business.parentElement
.querySelector('.form-error')
.textContent =
'Please enter business name';

valid = false;

}


// Phone

const phoneRegex =
/^[0-9]{10}$/;

const cleanPhone =
phone.value.replace(/\D/g,'');

if(!phoneRegex.test(cleanPhone)){

phone.parentElement
.querySelector('.form-error')
.textContent =
'Enter valid 10 digit number';

valid = false;

}


// City

if(city.value.trim().length < 2){

city.parentElement
.querySelector('.form-error')
.textContent =
'Enter city/location';

valid = false;

}


// Service

if(service.value === ''){

service.closest('.form__group')
.querySelector('.form-error')
.textContent =
'Select a service';

valid = false;

}


// Email

if(
email.value.trim() !== '' &&
!email.validity.valid
){

email.parentElement
.querySelector('.form-error')
.textContent =
'Enter valid email';

valid = false;

}

if(!valid){

e.preventDefault();

}

});

}